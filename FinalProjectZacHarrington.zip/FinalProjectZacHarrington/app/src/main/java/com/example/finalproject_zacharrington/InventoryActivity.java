package com.example.finalproject_zacharrington;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class InventoryActivity extends AppCompatActivity implements InventoryAdapter.ItemActions {

    private static final int REQ_SEND_SMS = 1001;

    private DBHelper db;
    private InventoryAdapter adapter;
    private String username; // passed from LoginActivity for phone lookup

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        db = new DBHelper(this);
        username = getIntent().getStringExtra("username");
        if (username == null) username = "";

        // Title shows logged in user
        findViewById(R.id.tvWelcome).setContentDescription("Inventory (User: " + username + ")");

        RecyclerView rv = findViewById(R.id.rvItems);
        rv.setLayoutManager(new GridLayoutManager(this, 2));
        adapter = new InventoryAdapter(db.getAllItems(), this);
        rv.setAdapter(adapter);

        findViewById(R.id.btnAdd).setOnClickListener(v ->
                AddItemDialog.newInstance((name, qty, reorder) -> {
                    db.addItem(name, qty, reorder);
                    refresh();
                }).show(getSupportFragmentManager(), "add_item_dialog"));

        // Prompt once; if denied, app still works without SMS alerts
        maybeRequestSmsPermission();
        refresh();

        findViewById(R.id.btnLogout).setOnClickListener(v -> {
            // Go back to login screen
            finish(); // closes InventoryActivity and returns to LoginActivity
        });
    }

    private void refresh() {
        List<Item> all = db.getAllItems();
        adapter.setData(all);
    }

    // === Adapter callbacks ===
    @Override
    public void onPlus(Item item) {
        int newQty = item.quantity + 1;
        if (db.updateItemQty(item.id, newQty)) refresh();
    }

    @Override
    public void onMinus(Item item) {
        int newQty = Math.max(0, item.quantity - 1);
        if (db.updateItemQty(item.id, newQty)) {
            refresh();
            if (newQty <= item.reorderLevel) {
                maybeSendLowStockAlert(item.name, newQty);
            }
        }
    }

    @Override
    public void onDelete(Item item) {
        if (db.deleteItem(item.id)) {
            Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
            refresh();
        }
    }

    // === SMS permission + sending ===
    private boolean hasSmsPermission() {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void maybeRequestSmsPermission() {
        if (!hasSmsPermission()) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    REQ_SEND_SMS);
        }
    }

    private void maybeSendLowStockAlert(String itemName, int qty) {
        if (!hasSmsPermission()) return; // silently skip if denied
        String phone = db.getUserPhone(username);
        if (phone == null || phone.trim().isEmpty()) return;

        try {
            String msg = "Low stock alert: \"" + itemName + "\" is at " + qty + ".";
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(phone, null, msg, null, null);
            Toast.makeText(this, "SMS alert sent to " + phone, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    // If the user responds to the permission prompt
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted (alerts enabled).", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied (app continues without alerts).", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
