package com.example.finalproject_zacharrington;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "inventory_app.db";
    private static final int DB_VERSION = 1;

    // --- Users table ---
    private static final String T_USERS = "users";
    private static final String C_USER_ID = "_id";
    private static final String C_USERNAME = "username";
    private static final String C_PASSWORD_HASH = "password_hash";
    private static final String C_PHONE = "phone";

    // --- Items table ---
    private static final String T_ITEMS = "items";
    private static final String C_ITEM_ID = "_id";
    private static final String C_ITEM_NAME = "name";
    private static final String C_ITEM_QTY = "quantity";
    private static final String C_ITEM_REORDER = "reorder_level";

    public DBHelper(Context ctx) {
        super(ctx, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String usersSql = "CREATE TABLE " + T_USERS + " (" +
                C_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                C_USERNAME + " TEXT UNIQUE NOT NULL," +
                C_PASSWORD_HASH + " TEXT NOT NULL," +
                C_PHONE + " TEXT" +
                ");";

        String itemsSql = "CREATE TABLE " + T_ITEMS + " (" +
                C_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                C_ITEM_NAME + " TEXT NOT NULL," +
                C_ITEM_QTY + " INTEGER NOT NULL," +
                C_ITEM_REORDER + " INTEGER NOT NULL DEFAULT 0" +
                ");";

        db.execSQL(usersSql);
        db.execSQL(itemsSql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + T_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + T_ITEMS);
        onCreate(db);
    }

    // ================= USERS =================

    public boolean createUser(String username, String password, String phone) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(C_USERNAME, username.trim());
        cv.put(C_PASSWORD_HASH, PasswordUtils.sha256(password)); // Hash password
        cv.put(C_PHONE, phone == null ? "" : phone.trim());

        long id = -1;
        try {
            id = db.insertOrThrow(T_USERS, null, cv);
        } catch (Exception ignored) {}
        return id != -1;
    }

    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        String[] cols = { C_USER_ID };
        String where = C_USERNAME + "=? AND " + C_PASSWORD_HASH + "=?";
        String[] args = { username.trim(), PasswordUtils.sha256(password) };
        Cursor c = db.query(T_USERS, cols, where, args, null, null, null);
        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }

    public String getUserPhone(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(T_USERS, new String[]{C_PHONE}, C_USERNAME + "=?",
                new String[]{username.trim()}, null, null, null);
        String phone = "";
        if (c.moveToFirst()) phone = c.getString(0);
        c.close();
        return phone == null ? "" : phone;
    }

    // ================= ITEMS =================

    public long addItem(String name, int qty, int reorder) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(C_ITEM_NAME, name.trim());
        cv.put(C_ITEM_QTY, qty);
        cv.put(C_ITEM_REORDER, reorder);
        return db.insert(T_ITEMS, null, cv);
    }

    public boolean deleteItem(long id) {
        SQLiteDatabase db = getWritableDatabase();
        int rows = db.delete(T_ITEMS, C_ITEM_ID + "=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }

    public boolean updateItemQty(long id, int newQty) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(C_ITEM_QTY, newQty);
        int rows = db.update(T_ITEMS, cv, C_ITEM_ID + "=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }

    public List<Item> getAllItems() {
        List<Item> out = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(T_ITEMS,
                new String[]{C_ITEM_ID, C_ITEM_NAME, C_ITEM_QTY, C_ITEM_REORDER},
                null, null, null, null, C_ITEM_NAME + " ASC");
        while (c.moveToNext()) {
            out.add(new Item(
                    c.getLong(0),
                    c.getString(1),
                    c.getInt(2),
                    c.getInt(3)
            ));
        }
        c.close();
        return out;
    }
}
