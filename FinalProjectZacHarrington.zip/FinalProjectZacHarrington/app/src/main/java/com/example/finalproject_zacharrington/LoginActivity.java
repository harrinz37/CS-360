package com.example.finalproject_zacharrington;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText etUsername, etPassword, etPhone;
    private DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        db = new DBHelper(this);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        etPhone    = findViewById(R.id.etPhone);

        findViewById(R.id.btnLogin).setOnClickListener(v -> doLogin());
        findViewById(R.id.btnCreateAccount).setOnClickListener(v -> doCreateAccount());
    }

    private void doLogin() {
        String u = etUsername.getText().toString();
        String p = etPassword.getText().toString();

        if (TextUtils.isEmpty(u) || TextUtils.isEmpty(p)) {
            Toast.makeText(this, "Enter username & password", Toast.LENGTH_SHORT).show();
            return;
        }

        if (db.validateUser(u, p)) {
            goToInventory(u);
        } else {
            Toast.makeText(this, "Invalid credentials. Create an account if new.", Toast.LENGTH_SHORT).show();
        }
    }

    private void doCreateAccount() {
        String u = etUsername.getText().toString();
        String p = etPassword.getText().toString();
        String phone = etPhone.getText().toString();

        if (TextUtils.isEmpty(u) || TextUtils.isEmpty(p)) {
            Toast.makeText(this, "Username & password required", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean ok = db.createUser(u, p, phone);
        if (ok) {
            Toast.makeText(this, "Account created. Logging in…", Toast.LENGTH_SHORT).show();
            goToInventory(u);
        } else {
            Toast.makeText(this, "Username already exists.", Toast.LENGTH_SHORT).show();
        }
    }

    private void goToInventory(String username) {
        Intent i = new Intent(this, InventoryActivity.class);
        i.putExtra("username", username);
        startActivity(i);
        finish();
    }
}
