package com.example.finalproject_zacharrington;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.VH> {

    interface ItemActions {
        void onPlus(Item item);
        void onMinus(Item item);
        void onDelete(Item item);
    }

    private List<Item> data;
    private final ItemActions actions;

    public InventoryAdapter(List<Item> data, ItemActions actions) {
        this.data = data;
        this.actions = actions;
    }

    public void setData(List<Item> newData) {
        this.data = newData;
        notifyDataSetChanged();
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        Item it = data.get(pos);
        h.tvName.setText(it.name);
        h.tvQty.setText("Qty: " + it.quantity);
        h.tvReorder.setText("Reorder at: " + it.reorderLevel);

        h.btnPlus.setOnClickListener(v -> actions.onPlus(it));
        h.btnMinus.setOnClickListener(v -> actions.onMinus(it));
        h.btnDelete.setOnClickListener(v -> actions.onDelete(it));
    }

    @Override
    public int getItemCount() { return data == null ? 0 : data.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvName, tvQty, tvReorder;
        Button btnPlus, btnMinus, btnDelete;
        VH(View v) {
            super(v);
            tvName = v.findViewById(R.id.tvItemName);
            tvQty = v.findViewById(R.id.tvQty);
            tvReorder = v.findViewById(R.id.tvReorder);
            btnPlus = v.findViewById(R.id.btnPlus);
            btnMinus = v.findViewById(R.id.btnMinus);
            btnDelete = v.findViewById(R.id.btnDelete);
        }
    }
}
