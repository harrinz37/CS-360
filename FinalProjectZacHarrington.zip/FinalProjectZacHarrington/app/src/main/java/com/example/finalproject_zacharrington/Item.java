package com.example.finalproject_zacharrington;

public class Item {
    public long id;
    public String name;
    public int quantity;
    public int reorderLevel;

    public Item(long id, String name, int quantity, int reorderLevel) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.reorderLevel = reorderLevel;
    }
}
