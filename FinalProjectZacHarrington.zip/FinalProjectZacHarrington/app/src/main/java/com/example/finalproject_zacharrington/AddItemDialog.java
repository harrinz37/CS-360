package com.example.finalproject_zacharrington;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class AddItemDialog extends DialogFragment {

    public interface OnItemAdded {
        void onItemAdded(String name, int qty, int reorder);
    }

    private OnItemAdded callback;

    public static AddItemDialog newInstance(OnItemAdded cb) {
        AddItemDialog d = new AddItemDialog();
        d.callback = cb;
        return d;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        var v = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_item, null, false);
        EditText etName = v.findViewById(R.id.etName);
        EditText etQty = v.findViewById(R.id.etQty);
        EditText etReorder = v.findViewById(R.id.etReorder);

        return new AlertDialog.Builder(getActivity())
                .setTitle("Add Item")
                .setView(v)
                .setPositiveButton("Add", (d, which) -> {
                    String n = etName.getText().toString();
                    String q = etQty.getText().toString();
                    String r = etReorder.getText().toString();
                    if (TextUtils.isEmpty(n) || TextUtils.isEmpty(q) || TextUtils.isEmpty(r)) {
                        Toast.makeText(getContext(), "All fields required", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    try {
                        int qty = Integer.parseInt(q);
                        int reorder = Integer.parseInt(r);
                        if (callback != null) callback.onItemAdded(n, qty, reorder);
                    } catch (NumberFormatException e) {
                        Toast.makeText(getContext(), "Enter valid numbers", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .create();
    }
}
